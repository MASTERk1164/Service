#ifndef UNICODE
#define UNICODE
#endif
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#define DONE (WM_APP+1)
static HWND w,mode,mins,secs,datebox,timebox,phrase,pointLabel,status,start,cancel,enterbox;
static HFONT font;
static POINT point;
static BOOL picked,choosing,running,sendEnter;
static ULONGLONG deadline;
static HANDLE event,thread;
static WCHAR text[16001];
static HWND ctl(LPCWSTR cls,LPCWSTR s,DWORD style,int x,int y,int width,int height,int id){
 HWND h=CreateWindowExW(0,cls,s,WS_CHILD|WS_VISIBLE|style,x,y,width,height,w,(HMENU)(INT_PTR)id,GetModuleHandleW(NULL),NULL);
 SendMessageW(h,WM_SETFONT,(WPARAM)font,TRUE);return h;
}
static void state(BOOL active){
 running=active;
 int ids[]={101,102,103,104,105,106,107,108,109};
 for(unsigned i=0;i<sizeof(ids)/sizeof(ids[0]);i++)EnableWindow(GetDlgItem(w,ids[i]),!active);
 EnableWindow(start,!active);EnableWindow(cancel,active);
}
static BOOL key(WORD code,DWORD flags){
 INPUT a[2]={0};a[0].type=a[1].type=INPUT_KEYBOARD;
 if(flags&KEYEVENTF_UNICODE)a[0].ki.wScan=a[1].ki.wScan=code;else a[0].ki.wVk=a[1].ki.wVk=code;
 a[0].ki.dwFlags=flags;a[1].ki.dwFlags=flags|KEYEVENTF_KEYUP;
 if(SendInput(2,a,sizeof(INPUT))==2)return TRUE;
 SendInput(1,&a[1],sizeof(INPUT));return FALSE;
}
static DWORD WINAPI execute(LPVOID arg){
 (void)arg;int result=0;
 while(GetTickCount64()<deadline){if(WaitForSingleObject(event,10)==WAIT_OBJECT_0){result=1;goto done;}}
 if(GetTickCount64()-deadline>2000){result=3;goto done;}
 if(WaitForSingleObject(event,0)==WAIT_OBJECT_0){result=1;goto done;}
 if(!SetCursorPos(point.x,point.y)){result=2;goto done;}
 INPUT a[2]={0};a[0].type=a[1].type=INPUT_MOUSE;a[0].mi.dwFlags=MOUSEEVENTF_LEFTDOWN;a[1].mi.dwFlags=MOUSEEVENTF_LEFTUP;
 if(SendInput(2,a,sizeof(INPUT))!=2){SendInput(1,&a[1],sizeof(INPUT));result=2;goto done;}
 if(WaitForSingleObject(event,300)==WAIT_OBJECT_0){result=1;goto done;}
 for(int i=0;text[i];i++){
  if(WaitForSingleObject(event,0)==WAIT_OBJECT_0){result=1;goto done;}
  if(text[i]=='\r')continue;
  if(!key(text[i]=='\n'?VK_RETURN:(WORD)text[i],text[i]=='\n'?0:KEYEVENTF_UNICODE)){result=2;goto done;}
 }
 if(sendEnter&&WaitForSingleObject(event,0)!=WAIT_OBJECT_0){if(!key(VK_RETURN,0))result=2;}
 done:PostMessageW(w,DONE,result,0);return 0;
}
static void arm(void){
 if(picked && GetAncestor(WindowFromPoint(point),GA_ROOT)==w){MessageBoxW(w,L"이 프로그램 바깥의 입력칸을 지정하세요.",L"위치 확인",MB_OK);return;}
 if(!picked){MessageBoxW(w,L"입력할 위치에 마우스를 놓고 F8을 누르세요.",L"위치 지정",MB_OK);return;}
 GetWindowTextW(phrase,text,16001);
 if(!text[0]){MessageBoxW(w,L"입력할 문구를 적어 주세요.",L"문구 확인",MB_OK);return;}
 ULONGLONG delay;
 if(SendMessageW(mode,CB_GETCURSEL,0,0)==0){
  BOOL a,b;UINT m=GetDlgItemInt(w,102,&a,FALSE),s=GetDlgItemInt(w,103,&b,FALSE);
  if(!a||!b||m>10080||s>59||(!m&&!s)){MessageBoxW(w,L"분은 0~10080, 초는 0~59이며 대기 시간은 1초 이상이어야 합니다.",L"시간 확인",MB_OK);return;}
  delay=((ULONGLONG)m*60+s)*1000;
 }else{
  SYSTEMTIME d,t,u;FILETIME f,now;
  DateTime_GetSystemtime(datebox,&d);DateTime_GetSystemtime(timebox,&t);
  d.wHour=t.wHour;d.wMinute=t.wMinute;d.wSecond=t.wSecond;d.wMilliseconds=0;
  if(!TzSpecificLocalTimeToSystemTime(NULL,&d,&u)||!SystemTimeToFileTime(&u,&f))return;
  GetSystemTimeAsFileTime(&now);
  ULONGLONG target=((ULONGLONG)f.dwHighDateTime<<32)|f.dwLowDateTime,current=((ULONGLONG)now.dwHighDateTime<<32)|now.dwLowDateTime;
  if(target<=current){MessageBoxW(w,L"현재보다 나중인 시간을 지정하세요.",L"시간 확인",MB_OK);return;}
  delay=(target-current)/10000;
 }
 if(!RegisterHotKey(w,2,MOD_NOREPEAT,VK_ESCAPE)){MessageBoxW(w,L"Esc 취소 단축키를 등록하지 못했습니다. 다른 예약 프로그램을 종료하고 다시 시도하세요.",L"예약 불가",MB_OK);return;}
 ResetEvent(event);sendEnter=SendMessageW(enterbox,BM_GETCHECK,0,0)==BST_CHECKED;deadline=GetTickCount64()+delay;state(TRUE);
 thread=CreateThread(NULL,0,execute,NULL,0,NULL);
 if(!thread){UnregisterHotKey(w,2);state(FALSE);SetWindowTextW(status,L"작업 시작 실패. 다시 시도하세요.");}
}
static LRESULT CALLBACK proc(HWND h,UINT msg,WPARAM wp,LPARAM lp){
 switch(msg){
 case WM_CREATE:
  w=h;font=CreateFontW(-17,0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Malgun Gothic");
  ctl(L"STATIC",L"예약 클릭 + 문구 입력",0,20,15,520,30,0);
  mode=ctl(WC_COMBOBOXW,L"",CBS_DROPDOWNLIST|WS_TABSTOP,20,55,180,100,101);
  SendMessageW(mode,CB_ADDSTRING,0,(LPARAM)L"지금부터 대기");SendMessageW(mode,CB_ADDSTRING,0,(LPARAM)L"날짜 · 시간 지정");SendMessageW(mode,CB_SETCURSEL,0,0);
  mins=ctl(L"EDIT",L"5",WS_BORDER|ES_NUMBER|WS_TABSTOP,215,55,65,26,102);ctl(L"STATIC",L"분",0,285,58,25,25,0);
  secs=ctl(L"EDIT",L"0",WS_BORDER|ES_NUMBER|WS_TABSTOP,320,55,65,26,103);ctl(L"STATIC",L"초 후 한 번 실행",0,390,58,160,25,0);
  datebox=ctl(DATETIMEPICK_CLASSW,L"",DTS_SHORTDATEFORMAT|WS_TABSTOP,20,95,180,28,104);
  timebox=ctl(DATETIMEPICK_CLASSW,L"",DTS_TIMEFORMAT|WS_TABSTOP,215,95,180,28,105);DateTime_SetFormat(timebox,L"HH':'mm':'ss");
  ctl(L"BUTTON",L"위치 지정 (F8)",WS_TABSTOP,20,140,180,32,106);
  pointLabel=ctl(L"STATIC",L"미지정 · 대상 입력칸 위에서 F8",0,215,145,355,30,0);
  ctl(L"STATIC",L"입력할 문구 (최대 16,000자)",0,20,185,520,25,0);
  phrase=ctl(L"EDIT",L"",WS_BORDER|WS_VSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_WANTRETURN|WS_TABSTOP,20,215,540,160,107);SendMessageW(phrase,EM_SETLIMITTEXT,16000,0);
  enterbox=ctl(L"BUTTON",L"입력 후 Enter 한 번 누르기",BS_AUTOCHECKBOX|WS_TABSTOP,20,390,530,28,108);
  ctl(L"STATIC",L"여러 줄 문구의 줄바꿈도 Enter로 입력됩니다.",0,20,425,540,25,0);
  start=ctl(L"BUTTON",L"예약 시작",WS_TABSTOP,20,465,260,40,109);
  cancel=ctl(L"BUTTON",L"취소 (Esc)",WS_TABSTOP,300,465,260,40,110);EnableWindow(cancel,FALSE);
  status=ctl(L"STATIC",L"대기 중 · 위치와 문구를 설정하세요.",0,20,525,540,60,0);
  if(!RegisterHotKey(w,1,MOD_NOREPEAT,VK_F8))SetWindowTextW(status,L"F8 사용 불가 · 위치 지정 버튼으로 3초 후 저장하세요.");
  event=CreateEventW(NULL,TRUE,FALSE,NULL);if(!event)return -1;
  SetTimer(w,1,100,NULL);return 0;
 case WM_COMMAND:
  if(LOWORD(wp)==106&&!running){choosing=TRUE;SetWindowTextW(status,L"3초 안에 대상 입력칸 위로 마우스를 이동하세요.");SetTimer(w,2,3000,NULL);}
  if(LOWORD(wp)==109&&!running){choosing=FALSE;KillTimer(w,2);arm();}
  if(LOWORD(wp)==110&&running)SetEvent(event);
  return 0;
 case WM_HOTKEY:
  if(wp==2&&running)SetEvent(event);
  if(wp!=1||running)return 0;
  /* F8 captures immediately, including during the three-second countdown. */
  choosing=TRUE;
  /* fall through */
 case WM_TIMER:
  if(choosing&&(msg==WM_HOTKEY||wp==2)){
   KillTimer(w,2);choosing=FALSE;GetCursorPos(&point);picked=TRUE;
   WCHAR s[120];swprintf(s,120,L"저장 위치: X %ld / Y %ld",point.x,point.y);SetWindowTextW(pointLabel,s);SetWindowTextW(status,L"위치 저장 완료. 문구를 입력하고 예약을 시작하세요.");
  }
  if(running){ULONGLONG now=GetTickCount64(),left=deadline>now?(deadline-now+999)/1000:0;WCHAR s[160];swprintf(s,160,L"%llu분 %02llu초 남음 · Esc로 취소\r\n대상 창과 입력칸 위치를 유지하세요.",left/60,left%60);SetWindowTextW(status,s);}
  return 0;
 case DONE:
  WaitForSingleObject(thread,INFINITE);CloseHandle(thread);thread=NULL;UnregisterHotKey(w,2);state(FALSE);
  SetWindowTextW(status,wp==0?L"입력 신호 전송 완료. 대상 화면에서 결과를 확인하세요.":wp==1?L"취소했습니다. 이미 입력된 내용은 유지됩니다.":wp==3?L"예약을 2초 이상 지나 실행을 건너뛰었습니다.":L"입력 전송 실패. 대상 앱의 권한과 상태를 확인하세요.");return 0;
 case WM_CLOSE:
  if(thread){SetEvent(event);WaitForSingleObject(thread,INFINITE);CloseHandle(thread);thread=NULL;}
  DestroyWindow(h);return 0;
 case WM_DESTROY:
  UnregisterHotKey(h,1);UnregisterHotKey(h,2);if(event)CloseHandle(event);DeleteObject(font);PostQuitMessage(0);return 0;
 }
 return DefWindowProcW(h,msg,wp,lp);
}
int WINAPI wWinMain(HINSTANCE inst,HINSTANCE prev,LPWSTR args,int show){
 (void)prev;(void)args;SetProcessDPIAware();INITCOMMONCONTROLSEX cc={sizeof(cc),ICC_DATE_CLASSES};InitCommonControlsEx(&cc);
 WNDCLASSW c={0};c.lpfnWndProc=proc;c.hInstance=inst;c.hCursor=LoadCursor(NULL,IDC_ARROW);c.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);c.lpszClassName=L"ScheduledTextWindow";RegisterClassW(&c);
 HWND h=CreateWindowW(c.lpszClassName,L"예약 클릭 + 문구 입력",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,600,640,NULL,NULL,inst,NULL);if(!h)return 1;
 ShowWindow(h,show);MSG m;while(GetMessageW(&m,NULL,0,0)>0){if(!IsDialogMessageW(h,&m)){TranslateMessage(&m);DispatchMessageW(&m);}}return 0;
}
